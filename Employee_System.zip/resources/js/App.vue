<script setup>
import Nav from "./components/Nav.vue";
import Sidebar from "./components/Sidebar.vue";
</script>

<template>
    <router-view></router-view>
</template>
