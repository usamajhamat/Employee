<script setup>

</script>
<template>
      <div
            class="mt-8 py-4 px-6 border-t border-slate-200 flex justify-between items-center text-sm text-slate-500"
        >
            <div>Copyright © 2019-{{ new Date().getFullYear() }}</div>
            <div class="flex items-center gap-1">
                Powered by
                <span class="font-semibold text-purple-600">Maven Wifi</span>
            </div>
        </div>
</template>