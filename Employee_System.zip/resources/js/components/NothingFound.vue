<script setup></script>

<template>
    <div :class="'p-24 flex flex-col items-center justify-center'">
        <img class="w-[300px]" src="../images/nothingFound.jpg" alt="" />
        <span class="text-4xl text-gray-700 mb-2">Oops!</span>
        <span class="text-lg text-muted-foreground">No results found.</span>
    </div>
</template>
