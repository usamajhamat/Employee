export { default as AreaChart } from "./AreaChart.vue";
